import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 userName1:string=localStorage.getItem("username");
 password1:string=localStorage.getItem("password");
 message:string;
 uname:string;
 psw:string;

  constructor(public router:Router) { 
    
  }
  onCancel()
  {
    this.router.navigate(['/Login'])
  }
  Onregister()
  {
    this.router.navigate(['/register'])
  }
  onLogin()
  {
    if(this.userName1===this.uname && this.password1===this.psw){
      this.router.navigate(['/product'])
    }
  }
 
  ngOnInit() {
  }

}
