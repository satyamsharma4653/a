import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  email:string;
  psw:string;
  constructor(public router:Router) { 
    
  }
  
 
  ngOnInit() {
  }

  onlogin(){
    localStorage.setItem("username",this.email)
    localStorage.setItem("password",this.psw)
    this.router.navigate(['/login'])
  }
}
