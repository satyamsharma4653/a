import { Component, OnInit } from '@angular/core';
import { IProduct } from 'src/app/model/user';
import { Router } from '@angular/router';
import { Product_data } from 'src/app/model/data';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
 products:IProduct[];

  constructor(public route:Router ,private service:ProductService) { }

  ngOnInit() {
    this.products=Product_data;
  }
  addtoCart(product)
  {
   this.service.addtocart(product);
  }
  toCart()
  {
  this.route.navigate(['./cart']);
  }
  toBackPage()
  {
    this.route.navigate(['./login']);
  }
}
