import { Injectable } from '@angular/core';
import { IProduct } from '../model/user';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  cart:IProduct[]=[]; 

  addtocart(product)
  {
    this.cart.push(product);
  }
  getCart()
  {
    return this.cart;
  }
  onDeleteItems(id:number,num:number)
  {
    this.cart.splice(id,num);
  }

  constructor() { }
}
