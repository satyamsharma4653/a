export class User {
  Username: string;
  Password: string;
  Firstname: string;
  Lastname: string;
  Email: string;
 MobileNo: number;

}
