import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/model/user';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

userName1: string = localStorage.getItem("username");
passWord1:string=localStorage.getItem("password");
message:string;

  constructor(private router : Router) { }

  ngOnInit() {
  }
  onLogin(f: NgForm) {
    if(this.userName1 === f.value.username && this.passWord1===f.value.password){
      this.router.navigate(['/products'])
    }
    else {
    this.message="UserName and Password Invalid"}
  }

}
