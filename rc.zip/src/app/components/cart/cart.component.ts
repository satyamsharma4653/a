import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProduct } from 'src/app/model/user';
import { ProductService } from 'src/app/service/product.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  carts:IProduct[];
  price:number;

  message:string;
  constructor(public router:Router,private service:ProductService ) { }

  ngOnInit(): void { 
    this.carts=this.service.getCart();
  }
  onDeleteItems(id:number)
  {
    this.service.onDeleteItems(id,1)
  }
Logout()
{
  this.router.navigate(['/login']);
}
onBack()
{
  this.router.navigate(['/product']);
}
}





