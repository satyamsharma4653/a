import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProduct } from 'src/app/model/user';
import { ProductService } from 'src/app/service/product.service';
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  tables:IProduct[];
  price:number;

  message:string;
  constructor(public router:Router,private service:ProductService ) { }

  ngOnInit(): void { 
    this.tables=this.service.getCart();
  }
  onDeleteItems(id:number)
  {
    {
      alert("Item Deleted");
    }
    this.service.onDeleteItems(id,1);
   
  }
 
Logout()
{
  this.router.navigate(['/login']);
}
onBack()
{
  this.router.navigate(['/product']);
}
toCart()
  {
  this.router.navigate(['./cart']);
  }
}
