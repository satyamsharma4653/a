
import { IProduct } from './user';
 export const Product_data:IProduct[]=[
     {
         productId:1,
         productName:"HP",
         description:"BlUE,4GM RAM,500GB storage",
         productRating:4.3,
         productCategory:"electronics",
         cost: 40000,
         image:"assets/images/b.png"
     },
     {
        productId:2,
        productName:"SONY",
        description:"GREY,32GB RAM,1000 GB storage",
        productRating:4.6,
        productCategory:"electronics",
        cost: 90000,
        image:"assets/images/c.png"
    },
    {
        productId:3,
        productName:"LENOVO",
        description:"BlACK,4GB RAM,1000 GB storage",
        productRating:4.5,
        productCategory:"electronics",
        cost: 35000,
        image:"assets/images/d.png"
    },
    {
        productId:4,
        productName:"APPLE",
        description:"WHITE,16GB RAM,2000 GB storage",
        productRating:4.8,
        productCategory:"electronics",
        cost: 120000,
        image:"assets/images/e.png"
    },
    {
        productId:5,
        productName:"ASUS",
        description:"BLACK,8GB RAM,1000 GB storage",
        productRating:3.9,
        productCategory:"electronics",
        cost: 49999,
        image:"assets/images/f.png"
    },
    {
        productId:6,
        productName:"Dell",
        description:"Blue,8GB RAM,500 GB storage",
        productRating:4.5,
        productCategory:"electronics",
        cost: 50000,
        image:"assets/images/g.png"
    }
 ]