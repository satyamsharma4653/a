import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ProductsComponent } from './components/products/products.component';
import { CartComponent } from './components/cart/cart.component';
import {TableComponent} from './components/table/table.component';

const routes: Routes = [{
path:"",
redirectTo:"login",
pathMatch:"full"
},
  {
    path: "login",
    component:LoginComponent
  },
  {
    path:"register",
    component:RegisterComponent
  },
  {
    path:"product",
    component:ProductsComponent
  },
  {
    path:"cart",
    component:CartComponent
  },
  {
    path:"table",
    component:TableComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
