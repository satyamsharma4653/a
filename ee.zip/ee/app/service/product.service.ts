import { Injectable } from '@angular/core';
import { IProduct } from '../model/user';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  cart:IProduct[]=[]; 
  table:IProduct[]=[];

  addtocart(product)
  {
    this.cart.push(product);
  }
  getCart()
  {
    return this.cart;
  }
  onDeleteItems(id:number,num:number)
  {
    this.cart.splice(id,num);
  }


//   addtocart(product)
//   {
//     this.table.push(product);
//   }
//   getCart()
//   {
//     return this.table;
//   }
//   onDeleteItems(id:number,num:number)
//   {
//     this.table.splice(id,num);
//   }



//   constructor() { }
//
 }
